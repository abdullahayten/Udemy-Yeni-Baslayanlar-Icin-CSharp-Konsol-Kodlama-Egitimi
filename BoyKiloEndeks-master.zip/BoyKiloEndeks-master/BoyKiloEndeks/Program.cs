﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoyKiloEndeks
{
    class Program
    {
        static void Main(string[] args)
        {
            //ideal kilo=(Boy - 100 + Yaş / 10) * k;
            //erkekler için k = 0.9;
            //kadınlar için k=0.8;

            int boy = 0;
            int kilo = 0;
            int yas = 0;
            char cinsiyet='e';
            double idealKilo = 0;
            Console.WriteLine("Hoşgeldiniz...");
            Console.WriteLine("Lütfen Kilonuzu Giriniz");
            kilo = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Lütfen Boyunuzu Giriniz");
            boy = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Lütfen Yaşınızı Giriniz");
            yas = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Lütfen Cinsiyeti Tek Harfle(e/k) Giriniz");
            cinsiyet = Convert.ToChar(Console.ReadLine());

            if (cinsiyet.Equals('e') || cinsiyet.Equals('E'))
            {
                idealKilo = ((boy - 100) + (yas / 10)) * 0.9;
            }
            else if (cinsiyet.Equals('k') || cinsiyet.Equals('K'))
            {
                idealKilo = ((boy - 100) + (yas / 10)) * 0.8;
            }
            else
            {
                Console.WriteLine("yanlış cinsiyet...");
            }


            if (kilo > idealKilo)
            {
                Console.WriteLine("Kilolu");
            }
            else if (kilo == idealKilo)
            {
                Console.WriteLine("İdeal Kilo");
            }
            else
            {
                Console.WriteLine("Zayıf");
            }

            Console.ReadKey();

        }
    }
}

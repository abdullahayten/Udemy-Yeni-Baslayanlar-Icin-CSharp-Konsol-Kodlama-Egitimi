﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiziSortveReverse
{
    class Program
    {
        static void Main(string[] args)
        {
            ////sort-- sıralamayı. küçükten büyüğe
            ////reverse-- tersle

            //int[] sayilar = { 23, 53, 64, 14, 86, 4 };

            ////Array.Sort(sayilar);
            //Array.Reverse(sayilar);

            //foreach(int sayi in sayilar)
            //{
            //    Console.WriteLine(sayi);
            //}

            //random 50 sayi üretilsin. diziye aktarılsın. küçükten büyüğe ve büyükten küçüğe sıralansın

            int[] dizimiz = new int[50];
            Random sdasdasd = new Random();
            int sayi = 0;

            for (int i = 0; i < 50; i++)
            {
                sayi = sdasdasd.Next(1, 100);
                dizimiz[i] = sayi;
            }

            Array.Sort(dizimiz);

            foreach (int sayimiz in dizimiz)
            {
                Console.WriteLine(sayimiz);
            }
            Console.WriteLine();
            Array.Reverse(dizimiz);
            foreach (int sayimiz in dizimiz)
            {
                Console.WriteLine(sayimiz);
            }

            Console.ReadKey();
        }
    }
}

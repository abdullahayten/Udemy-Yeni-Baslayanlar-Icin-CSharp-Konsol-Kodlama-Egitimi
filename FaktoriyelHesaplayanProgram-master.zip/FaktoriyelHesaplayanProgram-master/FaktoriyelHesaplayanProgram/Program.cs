﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FaktoriyelHesaplayanProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            // klavyeden girilen değerin faktörüyelini ehsaplayan programı yazınız...

            int sayi = 0;
            int faktoriyel = 1;

            Console.WriteLine("Faktöriyelini bulmak istedğiniz sayıyı giriniz..");
            sayi = Convert.ToInt32(Console.ReadLine());
            //3!   1*2*3
            for(int i=1;i<=sayi;i++)
            {
                faktoriyel = faktoriyel * i;
            }

            Console.WriteLine("Sonuç : " + faktoriyel); 
            Console.ReadKey();
        }
    }
}

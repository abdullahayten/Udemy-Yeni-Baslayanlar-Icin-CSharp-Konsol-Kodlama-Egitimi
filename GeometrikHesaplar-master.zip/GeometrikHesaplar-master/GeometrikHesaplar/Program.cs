﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeometrikHesaplar
{
    class Program
    {
        static void Main(string[] args)
        {
            //kare-dikdörtgen-daire-çember

            int kareKenar = 0;
            int kisaKenar = 0, uzunKenar = 0;
            double yaricap = 0;
            Console.WriteLine("Hoşgeldiniz...");

            //kare hesabı
            Console.WriteLine("Kare kenar giriniz...");
            kareKenar = Convert.ToInt16(Console.ReadLine());
            int kareCevre = kareKenar * 4;
            double kareAlan2 = Math.Pow(kareKenar, 2);
            
            //dikdörtgen hesabı
            Console.WriteLine("Dikdörtgenin Kısa kenarı giriniz...");
            kisaKenar = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Dikdörtgenin Uzun kenarı giriniz...");
            uzunKenar = Convert.ToInt16(Console.ReadLine());
            int dikCevre = (kisaKenar + uzunKenar) * 2;
            int dikAlan = kisaKenar * uzunKenar;

            //çember ve daire hesabı
            Console.WriteLine("Yarıçapı giriniz...");
            yaricap = Convert.ToDouble(Console.ReadLine());
            double cemberCevre = 2 * Math.PI * yaricap;
            double daireAlan = Math.PI * Math.Pow(yaricap, 2);



            Console.WriteLine("Karenin çevresi: " + kareCevre + " Karenin Alanı: " +kareAlan2);
            Console.WriteLine("Dikdörtgenin çevresi: " + dikCevre + " Dikdörtgenin Alanı: " + dikAlan);
            Console.WriteLine("Çemberin çevresi: " + cemberCevre + " Dairenin Alanı: " + daireAlan);



            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GithubProjem
{
    class Program
    {
        static void Main(string[] args)
        {
            //int double
            Console.WriteLine("Hoşgeldiniz...");
            Console.WriteLine("lütfen sayi1 giriniz...");

            int sayi1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("lütfen sayi2 giriniz...");
            double sayi2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("sonuç aşagıdaki gibidir...");
            Console.WriteLine(sayi1 + " - " + sayi2);
            

            Console.ReadKey();




            //double toplam = sayi1 + sayi2;
            //double fark = sayi1 - sayi2;
            //double carpim = sayi1 * sayi2;
            //double bolum = sayi1 / sayi2;

            //bolum = Math.Round(bolum, 3);

            //Console.WriteLine(toplam);
            //Console.WriteLine(fark);
            //Console.WriteLine(carpim);
            //Console.WriteLine(bolum);

            //char harf = 'k';
            //string cumle = "Lütfen yazınız...";
            //string bosluk = "     ";
            //Console.WriteLine(cumle +bosluk+ harf);
            ////Console.WriteLine(harf);
            //cumle = Console.ReadLine();
            //Console.WriteLine(cumle);
        }
    }
}

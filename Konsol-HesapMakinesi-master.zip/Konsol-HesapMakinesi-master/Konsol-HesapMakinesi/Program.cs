﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Konsol_HesapMakinesi
{
    class Program
    {
        static void Main(string[] args)
        {
            // + - * /
            int s1, s2,secilendeger;

            Console.WriteLine("******Hesap Makinesi******");
            Console.WriteLine("İlk sayıyı giriniz...");
            s1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("İkinci sayıyı giriniz...");
            s2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("İşlem Seçiniz (+ için 1, - için 2, * için 3, / için 4 tuşuna basınız)");
            secilendeger = Convert.ToInt32(Console.ReadLine());
            if(secilendeger==1)
            {
                Console.WriteLine(s1 + s2);
            }
            else if(secilendeger==2)
            {
                Console.WriteLine(s1 - s2);
            }
            else if(secilendeger==3)
            {
                Console.WriteLine(s1 * s2);
            }
            else if(secilendeger==4)
            {
                Console.WriteLine(s1 / s2);
            }
            else
            {
                Console.WriteLine("Tanımlanamayan giriş...");
            }
            Console.ReadKey();
        }
    }
}

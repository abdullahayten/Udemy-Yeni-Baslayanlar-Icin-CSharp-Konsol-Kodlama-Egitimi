﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Konsol_VizeFinalOrtalamaHesaplama
{
    class Program
    {
        static void Main(string[] args)
        {
            //0-44 kaldı
            //45-54 geçer
            //55-69 orta
            //70-84 iyi
            //85-100 pekiyi
            int vize1, vize2, final;
            double ortalama;

            Console.WriteLine("Ortalama Hesaplama Programı");
            Console.Write("1. Vize notu = ");
            vize1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("2. Vize notu = ");
            vize2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Final notu = ");
            final = Convert.ToInt32(Console.ReadLine());

            ortalama = (vize1 + vize2 + final) / 3;
            Console.WriteLine(ortalama);

            if (ortalama>=85 && ortalama<=100)
            {
                Console.WriteLine("pekiyi");
            }
            else if(ortalama>=70&&ortalama<=84)
            {
                Console.WriteLine("iyi");
            }
            else if (ortalama >= 55 && ortalama <= 69)
            {
                Console.WriteLine("orta");
            }
            else if (ortalama >= 45 && ortalama <= 54)
            {
                Console.WriteLine("gecer");
            }
            else if (ortalama >= 0 && ortalama <= 44)
            {
                Console.WriteLine("kaldınız... :(");
            }
            else if(ortalama>100 || ortalama <100)
            {
                Console.WriteLine("bir sorun var...");
            }

            Console.ReadKey();

        }
    }
}

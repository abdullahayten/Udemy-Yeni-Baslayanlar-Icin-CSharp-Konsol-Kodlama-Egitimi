﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaasPrimHesaplama
{
    class Program
    {
        static void Main(string[] args)
        {
            //Soru: Sattığı ürün sayısı 10dan düşükse her ürün için 50tl prim
            //eğer 10dan fazlaysa da her ürün için 100tl prim alsın.

            int personelMaas = 0;
            int satilanUrunSayisi = 0;

            Console.WriteLine("Prim Hesaplamaya Hoşgeldiniz...");
            Console.WriteLine("Lütfen Mevcut Maaşı Giriniz...");
            personelMaas = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Lütfen Satılan Ürün Sayısı Giriniz...");
            satilanUrunSayisi = Convert.ToInt16(Console.ReadLine());

            if (satilanUrunSayisi > 0 && satilanUrunSayisi <= 10)
            {
                personelMaas = personelMaas + (satilanUrunSayisi * 50);
            }
            else if(satilanUrunSayisi>10)
            {
                personelMaas = personelMaas + (satilanUrunSayisi * 100);
            }

            else
            {
                Console.WriteLine("tanımlanamayan giriş..");
            }

            Console.WriteLine(personelMaas);

            Console.ReadKey();
        }
    }
}

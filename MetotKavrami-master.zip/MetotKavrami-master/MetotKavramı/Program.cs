﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetotKavramı
{
    class Program
    {
        static void Main(string[] args)
        {
            sınıfornegi nesne = new sınıfornegi();
            nesne.selamyaz();
            nesne.selamyaz();
            nesne.selamyaz();
            nesne.selamyaz();
            nesne.selamyaz();
            Console.ReadKey();
        }


    }

    class sınıfornegi
    {
        public void selamyaz()
        {
            Console.WriteLine("sadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasdsadasdasdasd");
        }
    }
}

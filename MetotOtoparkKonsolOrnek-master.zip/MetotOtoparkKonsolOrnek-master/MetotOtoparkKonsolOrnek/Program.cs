﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetotOtoparkKonsolOrnek
{
    class Program
    {
        //araba,minibus,motorbisiklet,karavan,kamyon
        static void Main(string[] args)
        {
            Otopark oto = new Otopark();
            int tur = 0;
            Console.WriteLine("Araç Türünü Seçiniz... (araba(1),minibus(2),motorbisiklet(3),karavan(4),kamyon(5))");
            tur = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Kaç Saat Kaldı...");
            int saat = Convert.ToInt32(Console.ReadLine());

            switch (tur)
            {
                case 1: oto.ArabaHesapla(saat); break;
                case 2: oto.MinibusHesapla(saat); break;
                case 3: oto.MotorbisikletHesapla(saat); break;
                case 4: oto.KaravanHesapla(saat); break;
                case 5: oto.kamyonHesapla(saat); break;
                default: Console.WriteLine("Böyle bir araç yok "); break;
            }


            Console.ReadKey();
        }
    }

    class Otopark
    {
        public void ArabaHesapla(int saat)
        {
            int ucret = 0;
            ucret = saat * 5;
            Console.WriteLine(ucret);
        }
        public void MinibusHesapla(int saat)
        {
            int ucret = 0;
            ucret = (saat * 7) + 10;
            Console.WriteLine(ucret);
        }
        public void MotorbisikletHesapla(int saat)
        {
            int ucret = 0;
            ucret = (saat * 3) + 1;
            Console.WriteLine(ucret);
        }
        public void KaravanHesapla(int saat)
        {
            int ucret = 0;
            ucret = (saat * 11) + 34;
            Console.WriteLine(ucret);
        }
        public void kamyonHesapla(int saat)
        {
            int ucret = 0;
            ucret = (saat * 12);
            Console.WriteLine(ucret);
        }
    }

}

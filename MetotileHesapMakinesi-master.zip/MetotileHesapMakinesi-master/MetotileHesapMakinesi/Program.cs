﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetotileHesapMakinesi
{
    class Program
    {
        static void Main(string[] args)
        {
            Hesaplayıcı asdasd = new Hesaplayıcı();
            asdasd.Toplama(12, 23);
            asdasd.Cikarma(12, 23);
            asdasd.Carpma(12, 3);
            asdasd.Bolme(12, 3);
            Console.ReadKey();
        }
    }

    class Hesaplayıcı
    {
        public void Toplama(int a,int b)
        {
            Console.WriteLine(a + b);
        }

        public void Cikarma(int g ,int d)
        {
            Console.WriteLine(g - d);
        }

        public void Carpma(int o, int k)
        {
            Console.WriteLine(o * k);
        }

        public void Bolme(int e,int f)
        {
            Console.WriteLine(e / f);
        }
    }
}

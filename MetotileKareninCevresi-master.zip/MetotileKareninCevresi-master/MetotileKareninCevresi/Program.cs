﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetotileKareninCevresi
{
    class Program
    { //metotlarda parametre kullanımı
        //karenin kenarı giirlecek. çevresi hesaplanacak
        static void Main(string[] args)
        {
            Hesaplayıcı hes = new Hesaplayıcı();
            //int kenar = 0;
            //Console.WriteLine("Karenin kenarını giriniz...");
            //kenar = Convert.ToInt32(Console.ReadLine());
            //hes.CevreBul(kenar);


            hes.dikCevreBul(22, 5);

            Console.ReadKey();
        }
    }

    class Hesaplayıcı
    {
        public void CevreBul(int a)
        {
            Console.WriteLine(a * 4);
        }

        public void dikCevreBul(int a, int b)
        {
            Console.WriteLine((a + b) * 2);
        }
    }
}

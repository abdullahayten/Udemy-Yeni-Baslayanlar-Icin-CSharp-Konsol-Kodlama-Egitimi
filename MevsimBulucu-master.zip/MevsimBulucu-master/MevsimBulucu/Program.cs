﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MevsimBulucu
{
    class Program
    {
        static void Main(string[] args)
        {
            // girilen aya göre mevisimi belirten program
            int hangiAy = 0;

            Console.WriteLine("Lütfen bulmak istediğiniz ayı giriniz...");
            hangiAy = Convert.ToInt32(Console.ReadLine());

            switch (hangiAy)
            {
                case 12: Console.WriteLine("Aralık ayındasınız. Mevsim Kış"); break;
                case 1: Console.WriteLine("Ocak ayındasınız. Mevsim Kış"); break;
                case 2: Console.WriteLine("Şubat ayındasınız. Mevsim Kış"); break;
                case 3: Console.WriteLine("Mart ayındasınız. Mevsim İlkbahar"); break;
                case 4: Console.WriteLine("Nisan ayındasınız. Mevsim İlkbahar"); break;
                case 5: Console.WriteLine("Mayıs ayındasınız. Mevsim İlkbahar"); break;
                case 6: Console.WriteLine("Haziran ayındasınız. Mevsim Yaz"); break;
                case 7: Console.WriteLine("Temmuz ayındasınız. Mevsim Yaz"); break;
                case 8: Console.WriteLine("Ağustos ayındasınız. Mevsim Yaz"); break;
                case 9: Console.WriteLine("Eylül ayındasınız. Mevsim Sonbahar"); break;
                case 10: Console.WriteLine("Ekim ayındasınız. Mevsim Sonbahar"); break;
                case 11: Console.WriteLine("Kasım ayındasınız. Mevsim Sonbahar"); break;

                default:Console.WriteLine("Böyle bir ay bulunamadı...");break;
            }

            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SayisalLoto
{
    class Program
    {
        static void Main(string[] args)
        {
            //random sayı üretildi.
            Random rastgeleSayi=new Random();
            //int sayi = rastgeleSayi.Next(1, 50);
            //Console.WriteLine(sayi);
            //// 0-1-2-3-4-5
            int sayi = 0;
            for (int i = 0; i < 6; i++)
            {
                sayi = rastgeleSayi.Next(1, 50);
                Console.Write(sayi + " ");
            }


            Console.ReadKey();
        }
    }
}

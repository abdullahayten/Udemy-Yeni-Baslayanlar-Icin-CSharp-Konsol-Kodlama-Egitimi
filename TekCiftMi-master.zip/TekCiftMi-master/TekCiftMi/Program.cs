﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TekCiftMi
{
    class Program
    {
        static void Main(string[] args)
        {
            //kod kavramı
            int sayi1 = 0, sayi2 = 0, mod;
            Console.WriteLine("Tek-Çift Bulucu");
            Console.WriteLine("Sayı giriniz");
            sayi1 = Convert.ToInt16(Console.ReadLine());
            mod = sayi1 % 2;
            if (mod == 0)
            {
                Console.WriteLine("Girdiğiniz sayı çift sayıdır...");
            }
            else if (mod == 1)
            {
                Console.WriteLine("Girdiğiniz sayı tek sayıdır...");
            }
            else
            {
                Console.WriteLine("tanımlanamadı");
            }

            Console.WriteLine("Kalan:" + mod);
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelefonRehberiKonsolUygulamasi
{
    class Program
    {
        static void Main(string[] args)
        {
            //                  0       1       2       3       4
            string[] ad = { "ayşe", "fatma", "hayriye", "ali", "veli" };
            string[] mail = { "ayse@gmail.com", "fatma@gmail.com", "hayriye@gmail.com", "ali@gmail.com", "veli@gmail.com" };
            int[] telefon = { 11, 12, 13, 14, 15 };
            int sayi = 0;
            Console.WriteLine("Müşteri no giriniz...");
            sayi = Convert.ToInt32(Console.ReadLine());

            switch (sayi)
            {
                case 0: Console.WriteLine(ad[0] + "Telefon : " + telefon[0] + " Mail :" + mail[0]); break;
                case 1: Console.WriteLine(ad[1] + "Telefon :  " + telefon[1] + " Mail :" + mail[1]); break;
                case 2: Console.WriteLine(ad[2] + "Telefon : " + telefon[2] + " Mail :" + mail[2]); break;
                case 3: Console.WriteLine(ad[3] + "Telefon : " + telefon[3] + " Mail :" + mail[3]); break;
                case 4: Console.WriteLine(ad[4] + "Telefon : " + telefon[4] + " Mail :" + mail[4]); break;
                default: Console.WriteLine("böyle bir çalışan bulunamadı"); break;
            }
            Console.ReadKey();
        }
    }
}

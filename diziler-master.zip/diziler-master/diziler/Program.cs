﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace diziler
{
    class Program
    {
        static void Main(string[] args)
        {
            int girilendeger = 0;
            string [] gunler = { "pazartesi", "salı", "çarşamba", "perşembe", "cuma", "cumartesi", "pazar"};

            int[] dizim = new int[6];
            dizim[0] = 0;
            dizim[1] = 1;
            dizim[2] = 2;
            dizim[3] = 3;
            dizim[4] = 4;
            dizim[5] = 5;

            int[] dizi = { 0, 1, 2, 3, 4, 5, 6, 4, 2334, 2, 64 };
            //Console.WriteLine(dizi[2]);
            //Console.WriteLine(dizim[3]);
            girilendeger = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(gunler[girilendeger -1 ]);
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace foreachyapısı
{
    class Program
    {
        static void Main(string[] args)
        {
            //for vs foreach
            //int[] dizimizss = { 12, 2, 2, 3, 4 };
            int[] dizimiz = new int[7];
            dizimiz[0] = 12;
            dizimiz[1] = 3243;
            dizimiz[2] = 1123;
            dizimiz[3] = 33;
            dizimiz[4] = 22;

            //for(int i = 0; i <5; i++)
            //{
            //    Console.WriteLine(dizimiz[i]);

            //}

            foreach(int xaasdas in dizimiz)
            {
                Console.WriteLine(xaasdas);
            }

            //Console.WriteLine(dizimiz[0]);
            //Console.WriteLine(dizimiz[1]);
            //Console.WriteLine(dizimiz[2]);
            //Console.WriteLine(dizimiz[3]);
            //Console.WriteLine(dizimiz[4]);

            Console.ReadKey();
        }
    }
}

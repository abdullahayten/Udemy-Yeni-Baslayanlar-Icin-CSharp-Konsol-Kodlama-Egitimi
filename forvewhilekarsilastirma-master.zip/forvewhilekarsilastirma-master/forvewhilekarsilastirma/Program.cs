﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forvewhilekarsilastirma
{
    class Program
    {
        static void Main(string[] args)
        {
            //0dan 50 ye kadar olan çift sayıların toplamı

            int sayi = 0;
            int toplam = 0;

            ////for ile yapımı  0-2-4-6-8-10
            //for(sayi = 0; sayi <= 10; sayi = sayi + 2)
            //{
            //    toplam = toplam + sayi;
            //}
            //Console.WriteLine(toplam);

            while (sayi <= 50)
            {
                toplam = toplam + sayi;
                sayi = sayi + 2;
            }
            Console.WriteLine(toplam);
            Console.ReadKey();
        }
    }
}

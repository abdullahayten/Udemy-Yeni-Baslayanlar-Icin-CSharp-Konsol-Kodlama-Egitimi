﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace İkiBoyutluDiziler
{
    class Program
    {
        static void Main(string[] args)
        {
            //  123-43-54-33-66
            int[] tekboyutdizi = new int[5];

            //2,5
            // 123-43-54-33-66
            // 1204-3-5-2-6

            int[,] ikiboyutludizi = new int[2, 5];
            ikiboyutludizi[0, 0] = 123;
            ikiboyutludizi[0, 1] = 43;
            ikiboyutludizi[0, 2] = 54;
            ikiboyutludizi[0, 3] = 33;
            ikiboyutludizi[0, 4] = 66;
            ikiboyutludizi[1, 0] = 1204;
            ikiboyutludizi[1, 1] = 3;
            ikiboyutludizi[1, 2] = 5;
            ikiboyutludizi[1, 3] = 2;
            ikiboyutludizi[1, 4] = 6;

            for(int i = 0; i < 5; i++)
            {
                for(int j = 0; j < 2; j++)
                {
                    Console.WriteLine(ikiboyutludizi[j, i]);
                }
            }
            Console.ReadKey();

        }
    }
}

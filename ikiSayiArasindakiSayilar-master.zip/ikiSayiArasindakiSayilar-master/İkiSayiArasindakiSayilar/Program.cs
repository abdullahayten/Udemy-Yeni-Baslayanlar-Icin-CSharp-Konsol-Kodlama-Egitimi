﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace İkiSayiArasindakiSayilar
{
    class Program
    {
        static void Main(string[] args)
        {
            //2 sayı girilsin. Aradaki sayılar ekrana gelsin.

            Console.WriteLine("1. sayıyı giriniz....");
            int sayi1 = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("2. sayıyı giriniz....");
            int sayi2 = Convert.ToInt16(Console.ReadLine());

            if (sayi1 < sayi2)
            {
                Console.WriteLine("sayi 1 küçüktür");
                for (int i = sayi1; i <= sayi2; i++)
                {
                    Console.WriteLine(i);
                }
            }
            else
            {
                Console.WriteLine("sayi 2 küçüktür");

                for (int i = sayi2; i <= sayi1; i++)
                {
                    Console.WriteLine(i);
                }
            }



            Console.ReadKey();
        }
    }
}

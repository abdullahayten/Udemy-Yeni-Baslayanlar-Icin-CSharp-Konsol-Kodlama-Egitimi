﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace switchcaseyapisi
{
    class Program
    {
        static void Main(string[] args)
        {
            //hesap makinesi uygulaması

            int islemSec = 0;
            int sayi1 = 0;
            int sayi2 = 0;

            char islemsecisi = ' ';

            Console.WriteLine("1. sayıyı giriniz...");
            sayi1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("2. saııyı giriniz...");
            sayi2 = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("İşlem Seçiniz + (1), - (2), * (3), / (4)");
            Console.WriteLine("İşlem Seçiniz +, -, * , /");
            //islemSec = Convert.ToInt32(Console.ReadLine());
            islemsecisi = Convert.ToChar(Console.ReadLine());
            switch (islemsecisi)
            {
                case '+': Console.WriteLine("Toplam : " + (sayi1 + sayi2));break;
                case '-':Console.WriteLine("Fark : " + (sayi1 - sayi2));break;
                case '*':Console.WriteLine("Çarpım : " + (sayi1 * sayi2));break;
                case '/': Console.WriteLine("Bölüm : " + (sayi1 / sayi2));break;
                default:Console.WriteLine("İşlem bulunamadı...");break;
            }
            Console.ReadKey();
        }
    }
}

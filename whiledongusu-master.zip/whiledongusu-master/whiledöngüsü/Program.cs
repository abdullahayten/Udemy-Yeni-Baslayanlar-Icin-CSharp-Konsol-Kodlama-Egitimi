﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace whiledöngüsü
{
    class Program
    {
        static void Main(string[] args)
        {

            int sayi = 0;
            while (sayi<=3)
            {
                Console.WriteLine(sayi);
                sayi = sayi + 1;
            }

            Console.ReadKey();
        }
    }
}
